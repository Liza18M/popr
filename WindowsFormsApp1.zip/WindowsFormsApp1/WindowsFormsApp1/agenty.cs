﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Model2 db = new Model2();

      

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.ToList();
            agentTypeBindingSource.DataSource = db.AgentType.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //List<Agent> a = (List<Agent>)agentBindingSource.List;
            //a.Sort(APrioritySort);
            agentBindingSource.DataSource = db.Agent.OrderBy(a => a.Priority ).ToList();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.OrderBy(a => a.Title).ToList();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Редактирование frm = new Редактирование();
            DialogResult dr = frm.ShowDialog();
            if (dr == DialogResult.OK)
            { 
                agentBindingSource.DataSource = db.Agent.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Agent agent = (Agent)agentBindingSource.Current;
            try
            {
                if (agent == null) return;
                if (agent.Logo != "")
                {
                    string str = agent.Logo.Substring(1);
                    LogoPict.Image = Image.FromFile(str);
                }
                else
                {
                    LogoPict.Image = Image.FromFile("agents\\picture.png");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            string s = textBox1.Text.ToUpper();
            agentBindingSource.DataSource = db.Agent.
            Where(p => p.Title.ToUpper().Contains(s)).ToList();
        }
        //int APrioritySort(Agent a1, Agent a2)
        //{
        //    if (a1.Priority < a2.Priority)
        //        return 1;
        //    else if (a1.Priority == a2.Priority)
        //        return 0;
        //    else
        //        return +1;
        //}
    }
}
